<?php

session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

    include 'classes/livros.class.php';
    $livro = new Livros();

    if(!empty($_POST['id_livro'])){
        $titulo = $_POST['titulo'];
        $autor = $_POST['autor'];
        $editora = $_POST['editora'];
        $valor = $_POST['valor'];
        $foto = $_POST['foto'];
        $id_livro = $_POST['id_livro'];

        if(!empty($titulo)){
            $livro->editar($titulo, $autor, $editora, $valor, $foto, $id_livro);

        }
        header("Location: /rollmaster/adm/gerenciarLivro.php");
    }


?>