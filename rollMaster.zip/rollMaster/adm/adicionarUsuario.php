<?php
session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

?>


<h1 class="text-center">ADICIONAR USUÁRIO</h1>
<div class="row justify-content-center">
    <form method="POST" action="adicionarUsuarioSubmit.php" class="d-fluid c">
        Nome: <br>
        <input type="text" name="nome" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Nickname: <br>
        <input type="text" name="nickname" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Email: <br>
        <input type="text" name="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Senha: <br>
        <input type="password" name="senha" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>

        <input type="submit" name="btCadastrar" class="btn btn-purple" value="ADICIONAR">

    </form>
</div>