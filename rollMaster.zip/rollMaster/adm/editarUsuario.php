<?php

session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

    include 'classes/contatos.class.php';
    $usuario = new User();

    if(!empty($_GET['id_user'])){
        $id_user = $_GET['id_user'];
        $info = $usuario->buscar($id_user);
        if(empty($info['email'])){
            header("Location: /rollmaster");
            exit;
        }

    }else{
        header("Location: /rollmaster/adm/gerenciarUsuario.php");
        exit;
    }
?>

<h1 class="text-center">EDITAR USUÁRIO</h1>

<div class="row justify-content-center">
<form method="POST" action="editarUsuarioSubmit.php" class="d-fluid c">
    <input type="hidden" name="id_user" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['id_user']?>"/>
    Nome: <br>
    <input type="text" name="nome"  class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['nome']?>"/><br><br>
    Nickname: <br>
    <input type="text" name="nickname"  class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['nickname']?>"/><br><br>
    Email: <br>
    <input type="text" name="email"  class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['email']?>"/><br><br>
    Senha: <br>
    <input type="password" name="senha"  class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['senha']?>"/><br><br>

    <input type="submit" name="btEditar" class="btn btn-purple" value="Adicionar"/>

</form>
</div>