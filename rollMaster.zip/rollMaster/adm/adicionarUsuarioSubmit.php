<?php
session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

include 'classes/contatos.class.php';
$usuario = new User();

if(!empty($_POST['email'])){
    $nome = $_POST['nome'];
    $nickname = $_POST['nickname'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $usuario->adicionar( $nome, $nickname, $email, $senha);

    header('Location:gerenciarUsuario.php');   
}

    
else{
    echo '<script type="text/javascript">alert("Email já cadastrado!");</script>';
}



?>