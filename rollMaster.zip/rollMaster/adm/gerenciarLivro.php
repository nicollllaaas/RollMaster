<?php
session_start();

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

?>


    <?php
    include 'inc/header.inc.php';
    include 'classes/livros.class.php';
    $livro = new Livros();
    ?>
    <h1 class="text-center">Cadastrar um Livro</h1>
    <hr>
    <button type="submit" class="btn btn-purple"><a href="adicionarLivro.php"class="text-light">ADICIONAR LIVRO</a></button>
    <br><br>
    <table class="table table-dark table-striped" border = "2" width = 90% style="margin-bottom: 180px;">
        <tr>
            <th>IdLivro</th>
            <th>Título</th>
            <th>Autor</th>
            <th>Editora</th>
            <th>Valor</th>
            <th>Foto</th>
        </tr>
        <?php
            $lista = $livro->listar();
            foreach($lista as $item) :
        ?>
        <tbody>
            <tr>
                <td><?php echo $item['id_livro']?></td>
                <td><?php echo $item['titulo']?></td>
                <td><?php echo $item['autor']?></td>
                <td><?php echo $item['editora']?></td>
                <td><?php echo  'R$ ', $item['valor'], ',00' ?></td>
                <td><?php echo $item['foto'] ?></td>

                <td>
                    <a class="btn btn-info btn-sm" href="editarLivro.php?id_livro=<?php echo $item ['id_livro'];?>">EDITAR</a> |
                    <a class="btn btn-danger btn-sm" href="excluirLivro.php?id_livro=<?php echo $item['id_livro']?>"onclick = "return comfirm('Você tem certeza?')"> EXCLUIR</a>
                </td>
            </tr>
        </tbody>
        <?php
        endforeach;
        ?>
    </table>
    <?php
        include 'inc/footer.inc.php';
    ?>
</body>


