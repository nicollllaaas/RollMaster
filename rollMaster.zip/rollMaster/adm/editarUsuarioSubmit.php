<?php

session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

    include 'classes/contatos.class.php';
    $usuario = new User();

    if(!empty($_POST['id_user'])){
        $nome = $_POST['nome'];
        $nickname = $_POST['nickname'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $id_user = $_POST['id_user'];

        if(!empty($email)){
            $usuario->editar($nome, $nickname, $email, $senha, $id_user);

        }
        header("Location: /rollmaster/adm/gerenciarUsuario.php");
    }


?>