<?php
session_start();

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

?>


    <?php
    include 'inc/header.inc.php';
    include 'classes/contatos.class.php';
    $usuario = new User();
    ?>
    <h1 class="text-center">Cadastrar um Usuario</h1>
    <hr>
    <button type="submit" class="btn btn-purple"><a href="adicionarUsuario.php"class="text-light">ADICIONAR USUARIO</a></button>
    <br><br>
    <table class="table table-dark table-striped" border = "2" width = 90% style="margin-bottom: 180px;">
        <tr>
            <th>IdUsuario</th>
            <th>Nome</th>
            <th>Nickname</th>
            <th>Email</th>
            <th>Senha</th>
        </tr>
        <?php
            $lista = $usuario->listar();
            foreach($lista as $item) :
        ?>
        <tbody>
            <tr>
                <td><?php echo $item['id_user']?></td>
                <td><?php echo $item['nome']?></td>
                <td><?php echo $item['nickname']?></td>
                <td><?php echo $item['email']?></td>
                <td><?php echo '*****' ?></td>

                <td>
                    <a class="btn btn-info btn-sm" href="editarUsuario.php?id_user=<?php echo $item ['id_user'];?>">EDITAR</a> |
                    <a class="btn btn-danger btn-sm" href="excluirUsuario.php?id_user=<?php echo $item['id_user']?>"onclick = "return comfirm('Você tem certeza?')"> EXCLUIR</a>
                </td>
            </tr>
        </tbody>
        <?php
        endforeach;
        ?>
    </table>
    <?php
        include 'inc/footer.inc.php';
    ?>
</body>


