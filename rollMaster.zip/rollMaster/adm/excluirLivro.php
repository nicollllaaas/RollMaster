<?php
session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

include 'classes/livros.class.php';
$livro = new Livros();

if(!empty($_GET['id_livro'])){
    $id_livro = $_GET['id_livro'];
    $livro->excluir($id_livro);
    
    header("Location: /rollMaster/adm/gerenciarLivro.php");

}
else{
    echo '<script type="text/javascript">alert("Erro ao excluir contato!");</script>';
    header("Location: /rollMaster/adm/gerenciarUsuario.php");
}