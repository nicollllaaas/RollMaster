<?php
session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

include 'classes/contatos.class.php';
$usuario = new User();

if(!empty($_GET['id_user'])){
    $id_user = $_GET['id_user'];
    $usuario->excluir($id_user);
    
    header("Location: /rollMaster/adm/gerenciarUsuario.php");

}
else{
    echo '<script type="text/javascript">alert("Erro ao excluir contato!");</script>';
    header("Location: /rollMaster/adm/gerenciarUsuario.php");
}