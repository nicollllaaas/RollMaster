<?php
session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

include 'classes/livros.class.php';
$livro = new Livros();

if(!empty($_POST['titulo'])){
    $titulo = $_POST['titulo'];
    $autor = $_POST['autor'];
    $editora = $_POST['editora'];
    $valor = $_POST['valor'];
    $foto = $_POST['foto'];

    $livro->adicionar( $titulo, $autor, $editora, $valor, $foto);

    header('Location:gerenciarLivro.php');   
}

    
else{
    echo '<script type="text/javascript">alert("Email já cadastrado!");</script>';
}



?>