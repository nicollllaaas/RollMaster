<?php
    require_once 'conexao.class.php';

    class Livros{
        
        private $id_livro;
        private $titulo;
        private $autor;
        private $editora;
        private $valor;
        private $foto;

        private $con;
        
        public function __construct(){
            $this->con = new Connect();
        }
        
        private function existeTitulo($titulo){
            $sql = $this->con->conectar()->prepare("SELECT id_livro FROM livros WHERE titulo = :titulo");
            $sql->bindParam(':titulo', $titulo, PDO::PARAM_STR);
            $sql->execute();

            if($sql->rowCount() > 0){
                $array = $sql->fetch();
            }else{
                $array = array();
            }
            return $array;
        }
        public function adicionar($titulo, $autor, $editora, $valor, $foto){
            $tituloExistente = $this->existeTitulo($titulo);
            if(count($tituloExistente) == 0){
                try{
                    $this->titulo = $titulo;
                    $this->autor = $autor;
                    $this->editora = $editora;
                    $this->valor = $valor;
                    $this->foto = $foto;
                    $sql = $this->con->conectar()->prepare("INSERT INTO livros(titulo, autor, editora, valor, foto)VALUES(:titulo, :autor, :editora, :valor, :foto)");
                    $sql->bindParam(":titulo", $this->titulo, PDO::PARAM_STR);
                    $sql->bindParam(":autor", $this->autor, PDO::PARAM_STR);
                    $sql->bindParam(":editora", $this->editora, PDO::PARAM_STR);
                    $sql->bindParam(":valor", $this->valor, PDO::PARAM_STR);
                    $sql->bindParam(":foto", $this->foto, PDO::PARAM_STR);
                    $sql->execute();

                    return TRUE;
                }catch(PDOException $ex){
                    return 'ERRO: '.$ex->getMessage();
                }
            }else{
                return FALSE;
            }
        }
        public function listar(){
            try{
                $sql = $this->con->conectar()->prepare("SELECT id_livro, titulo, autor, editora, valor, foto FROM livros");
                $sql->execute();
                return $sql->fetchAll();
            }catch(PDOException $ex){
                return 'ERRO: '.$ex->getMessage();
            }
        }
        public function buscar($id_livro){
            try{
                $sql = $this->con->conectar()->prepare("SELECT * FROM livros WHERE id_livro = :id_livro");
                $sql->bindValue(':id_livro', $id_livro);
                $sql->execute();
                if($sql->rowCount() > 0){
                    return $sql->fetch();
                }else{
                    return array();
                }
            }catch(PDOException $ex){
                echo"ERRO: ".$ex->getMessage();
            }
        }
        public function editar($titulo, $autor, $editora, $valor, $foto, $id_livro){
            $tituloExistente = $this->existeTitulo($titulo);
            if(count($tituloExistente) > 0 && $tituloExistente['id_livro'] != $id_livro){
                return FALSE;
            }else{
                try{
                    $sql = $this->con->conectar()->prepare("UPDATE livros SET titulo = :titulo, autor = :autor, editora = :editora, valor = :valor, foto = :foto WHERE id_livro = :id_livro");
                    $sql->bindValue(':titulo', $titulo);
                    $sql->bindValue(':autor', $autor);
                    $sql->bindValue(':editora', $editora);
                    $sql->bindValue(':valor', $valor);
                    $sql->bindValue(':foto', $foto);
                    $sql->bindValue(':id_livro', $id_livro);
                    $sql->execute();
                    return TRUE;
                }
                catch(PDOException $ex){
                    echo 'ERRO: '.$ex->getMessage();
                }
            }
        }
        public function excluir($id_livro){
            $sql = $this->con->conectar()->prepare("DELETE FROM livros WHERE id_livro = :id_livro");
            $sql->bindValue(':id_livro', $id_livro);
            $sql->execute();
        }
    
            
        

    }







?>