<?php

require 'conexao.class.php';
class User{
    private $id_user;
    private $nome;
    private $nickname;
    private $email;
    private $senha;

    private $con;

    public function __construct(){
        $this->con = new Connect();
    }
    private function existeEmail($email){
        $sql = $this->con->conectar()->prepare("SELECT id_user FROM usuario WHERE email = :email");
        $sql->bindParam(':email', $email, PDO::PARAM_STR);
        $sql->execute();

        if($sql->rowCount() > 0){
            $array = $sql->fetch();
        }
        else{
            $array = array();
        }
        return $array;
    }
    public function adicionar($nome, $nickname, $email, $senha){
        $emailExistente = $this->existeEmail($email);
        if(count($emailExistente) == 0){
            try{
                $this->nome = $nome;
                $this->nickname = $nickname;
                $this->email = $email;
                $this->senha = $senha;
                $sql = $this->con->conectar()->prepare("INSERT INTO usuario(nome, nickname, email, senha) VALUES(:nome, :nickname, :email, :senha)");
                $sql->bindParam(":nome", $this->nome, PDO::PARAM_STR);
                $sql->bindParam(":nickname", $this->nickname, PDO::PARAM_STR);
                $sql->bindParam(":email", $this->email, PDO::PARAM_STR);
                $sql->bindParam(":senha", md5($this->senha), PDO::PARAM_STR);
                $sql->execute();

                return TRUE;   
            }
            catch(PDOException $ex){
                return 'ERRO: ' .$ex->getMessage();
            }
        }
        else{
            return FALSE;
        }
    }
    public function listar(){
        try{
            $sql = $this->con->conectar()->prepare("SELECT id_user, nome, nickname, email, senha FROM usuario");
            $sql->execute();
            return $sql->fetchAll();
           
    }
    catch(PDOException $ex){
        return 'ERRO: '.$ex->getMessage();
    }
}
public function buscar($id_user){
    try{
        $sql = $this->con->conectar()->prepare("SELECT * FROM usuario WHERE id_user = :id_user");
        $sql->bindValue(':id_user', $id_user);
        $sql->execute();
        if($sql->rowCount() > 0){
            return $sql->fetch();
        }
        else{
            return array();
        }
    }
    catch(PDOException $ex){
        echo "ERRO: " .$ex->getMessage();
    }
}

public function editar($nome, $nickname, $email, $senha, $id_user){
    $emailExistente = $this->existeEmail($email);
    if(count($emailExistente) > 0 && $emailExistente['id_user'] != $id_user){
        return FALSE;
    }
    else{
        try{
            $sql = $this->con->conectar()->prepare("UPDATE usuario SET nome = :nome, nickname = :nickname, email = :email, senha = :senha WHERE id_user = :id_user");
            $sql->bindValue('nome', $nome);
            $sql->bindValue('nickname', $nickname);
            $sql->bindValue('email', $email);
            $sql->bindValue('senha', $senha);
            $sql->bindValue('id_user', $id_user);
            $sql->execute();
            return TRUE;
        }
        catch(PDOException $ex){
            echo 'ERRO: ' .$ex->getMessage();
        }
    }
}


public function excluir ($id_user){
    $sql = $this->con->conectar()->prepare("DELETE FROM usuario WHERE id_user = :id_user");
    $sql->bindValue(':id_user', $id_user);
    $sql->execute();
}

public function esqueceSenha($email)
{
    try
    {
        $emailExistente = $this->existeEmail($email);

        $sql = $this->con->conectar()->prepare("SELECT id_user FROM usuario WHERE email = :email");
        $sql->bindValue(":email", $email);
        $sql->execute();

        if($sql->rowCount() > 0){
            return $sql->fetch();
        }else{
            return array();
        }
    }
    catch(PDOException $ex)
    {
        echo 'ERRO: '.$ex->getMessage();
    }
} 

}
?>

