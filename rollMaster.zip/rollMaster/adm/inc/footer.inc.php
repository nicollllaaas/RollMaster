<footer>
    

    <hr>
    <h4 class="text-light">&copy Todos os direitos reservados </h4>

    </footer>

    <script type="text/javascript" src="js/jquery-3.7.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"> </script>
    </div>
</body>
</html>