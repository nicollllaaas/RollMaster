<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href="css/bootstrap.min.css">
    
    <title>RollMaster</title>
</head>
<body>
<div class="fluid-container ">
    <header>
        <div class=" navbar navbar-dark bg-dark">
            <div class = "container d-flex  justify-content-between">
                <a href="admin.php" class=" navbar-brand" style="font-size: 250%">
                    <img src="img/logo.png" alt="" style="width: 20%; position: relative;">
                    RollMaster
                </a>
            <link rel = "stylesheet" type = "text/css" href = "css/style.css">
                
            </div> 
        </div>
       
    </header>


