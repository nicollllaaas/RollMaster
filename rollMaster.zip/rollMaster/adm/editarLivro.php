<?php

session_start();
include 'inc/header.inc.php';


if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

    include 'classes/livros.class.php';
    $livro = new Livros();

    if(!empty($_GET['id_livro'])){
        $idLivro = $_GET['id_livro'];
        $info = $livro->buscar($idLivro);
        if(empty($info['titulo'])){
            header("Location: gerenciarLivro.php");
            exit;
        }

    }else{
        header("Location: /rollmaster/adm/gerenciarLivro.php");
        exit;
    }
?>

<h1 class="text-center">EDITAR LIVRO</h1>
<div class="row justify-content-center">
    <form method="POST" action="editarLivroSubmit.php" class="d-fluid c">
        <input type="hidden" name="id" value=<?php echo $info['id_livro']?>/>
        Título: <br>
        <input type="text" name="titulo" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value=<?php echo $info['titulo']?>/><br><br>
        Autor: <br>
        <input type="text" name="autor" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value=<?php echo $info['autor']?>/><br><br>
        Editora: <br>
        <input type="text" name="editora" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"value=<?php echo $info['editora']?>/><br><br>
        Valor: <br>
        <input type="float" name="valor" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"value=<?php echo $info['valor']?>/><br><br>
        Foto: <br>
        <input type="text" name="foto" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"value=<?php echo $info['foto']?>/><br><br>

        <input type="submit" name="btCadastrar" class="btn btn-purple" value="ALTERAR">

    </form>
</div>

<?php 
    include 'inc/footer.inc.php';
?>