<?php
session_start();
include 'inc/header.inc.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}

?>


<h1 class="text-center">ADICIONAR LIVRO</h1>
<div class="row justify-content-center">
    <form method="POST" action="adicionarLivroSubmit.php" class="d-fluid c">
        Título: <br>
        <input type="text" name="titulo" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Autor: <br>
        <input type="text" name="autor" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Editor: <br>
        <input type="text" name="editora" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Valor: <br>
        <input type="float" name="valor" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>
        Foto: <br>
        <input type="text" name="foto" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default"/><br><br>

        <input type="submit" name="btCadastrar" class="btn btn-purple" value="ADICIONAR">

    </form>
</div>

<!-- titulo autor editora valor foto -->