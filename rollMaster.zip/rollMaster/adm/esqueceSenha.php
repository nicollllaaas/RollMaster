<?php
include 'inc/header.inc.php';
include 'classes/contatos.class.php';
 
    $email = $_POST['email'];
 
    $user = new User();
 
    $teste = $user->esqueceSenha($email);
 
    $id_user = $teste['id_user'];
 
    $info = $user->buscar($id_user);
?>


<h1 class="text-center" style="margin-bottom: 120px">ALTERE SUA SENHA</h1>
<div class="row justify-content-center">
    <form method="POST" action="esqueceSenhaSubmit.php">
    
    <input type="hidden" name="id_user" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['id_user'] ?>" /> 
    <input type="hidden" name="nome" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['nome'] ?>" />
    <input type="hidden" name="nickname" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['nickname'] ?>" />
    <input type="hidden" name="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?php echo $info['email'] ?>" />
        Senha: <br>
        <input type="password" name="senha" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" /><br><br>

        <input type="submit" class="btn btn-success" style="margin-bottom: 150px" name="btCadastrar" value="Alterar" />
    </form>
</div style="margin-bottom: 100px">

<?php
include 'inc/footer.inc.php';
?>