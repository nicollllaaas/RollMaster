<?php
  session_start();
  require_once 'inc/header.inc.php';
  require 'classes/admin.class.php';

  if(!empty($_POST['email'])){
    $email = addslashes($_POST['email']);
    $senha = md5($_POST['senha']);
    
    $admins = new Admin();
    if($admins->fazerLogin($email, $senha)){
      header("Location: admin.php");
      exit;
    }
    else{
      echo '<span style = "color: red">'."USUARIO E/OU SENHA INCORRETOS".'</span>';
    }
  }
?>

    


    <h1 style=" text-align: center;">Admin da RollMaster </h1>

    
    
<div class="login-container">
  <h2>Login</h2>
  <form method="POST">
    <input type="text" name="email" placeholder="Usuário" required>
    <input type="password" name="senha" placeholder="Senha" required>
    <input type="submit" value="Entrar">
  </form>
  <a href="esqueceSenha2.php" class="text-white mt-1">Esqueci minha senha</a>
</div>


 <?php
 include 'inc/footer.inc.php';
?>

