<?php
session_start();
include 'inc/header.inc.php';
//include 'classes/admin.class.php';
//include 'classes/contatos.class.php';

if(!isset($_SESSION['Logado'])){
    header("Location: login.php");
    exit;
}
/*admins = new Admin();
$admins->setUsuario($_SESSION['Logado']);
$usuario = new User();*/
?>

    


    <h1 style=" text-align: center;">Admin da RollMaster </h1>
    <hr>
    
    <h3><a class="text-dark" style="margin-left: 10px;" href="gerenciarUsuario.php"> Gerenciar Usuário</a></h3><br><br>
    <h3><a class="text-dark" style="margin-left: 10px;" href="gerenciarLivro.php">Gerenciar Livros</a></h3><br><br><br><br>

    <button class="btn-danger" style="margin-left: 10px; margin-bottom: 180px;"><a class="text-light" href="logout.php">SAIR</a></button>


 <?php
 include 'inc/footer.inc.php';
?>
