<?php
include 'classes/contatos.class.php';
$usuarios = new User();

if(!empty ($_POST['id_user'])){
    $nome = $_POST['nome'];
    $nickname = $_POST['nickname'];
    $email = $_POST['email'];
    $senha = md5($_POST['senha']);
    $id_user = $_POST['id_user'];
    
    if(!empty($email)){
        $usuarios->editar($nome, $nickname, $email, $senha, $id_user);
    }
    header("Location: login.php?status=success");
}

?>  