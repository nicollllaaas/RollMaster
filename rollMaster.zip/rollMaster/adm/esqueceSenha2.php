<?php 
include 'inc/header.inc.php';
include 'classes/contatos.class.php';
?>

<h1 class="text-center" style="margin-bottom: 120px">QUAL USUARIO DESEJA ALTERAR?</h1>
<div class="row justify-content-center">
    <form method="POST" action="esqueceSenha.php">
        Email: <br>
        <input type="text" name="email" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" /><br><br>
    
        <input type="submit" class="btn btn-success" style="margin-bottom: 150px" name="btCadastrar" value="Alterar" />
    </form>
</div style="margin-bottom: 100px">

<?php
include 'inc/footer.inc.php';
?>